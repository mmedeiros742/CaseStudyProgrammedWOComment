#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 17:25:45 2020

@author: ericbotelho
"""

import pandas as pd
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Supplied = (CStudy["Supplied or from scratch?"] == 1).sum()
Scratch = (CStudy["Supplied or from scratch?"] == 2).sum()

labels = ["Supplied", "From Scratch"]
sizes = [Supplied, Scratch]
explode = (0.01, 0)
colors = ['#ff9999','#66b3ff']

fig1, ax1 = plt.subplots()
piechart = ax1.pie(sizes, explode = explode, labels = labels, colors = colors, autopct='%1.1f%%')
ax1.set_title("Supplied or form Scartch Code") 
plt.savefig("Supplied or from Scratch Code Pie Chart.png")