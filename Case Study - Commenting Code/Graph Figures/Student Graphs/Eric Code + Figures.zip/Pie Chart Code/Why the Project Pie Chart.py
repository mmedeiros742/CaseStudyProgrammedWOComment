#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 17:16:37 2020

@author: ericbotelho
"""

import pandas as pd
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Hobby = (CStudy["Why the project?"] == 1).sum()
Job = (CStudy["Why the project?"] == 2).sum()
School = (CStudy["Why the project?"] == 3).sum()

labels = ["Hobby", "Job", "School"]
sizes = [Hobby, Job, School]
explode = (0.01, 0, 0)
colors = ['#ff9999','#66b3ff','#99ff99']

fig1, ax1 = plt.subplots()
piechart = ax1.pie(sizes, explode = explode, labels = labels, colors = colors, autopct='%1.1f%%')
ax1.set_title("Why the Project?") 
plt.savefig("Why the Project Pie Chart.png")