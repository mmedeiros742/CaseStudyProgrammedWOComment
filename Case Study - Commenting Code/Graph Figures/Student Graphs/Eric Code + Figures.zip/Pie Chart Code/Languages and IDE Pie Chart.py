#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 16:43:35 2020

@author: ericbotelho
"""

import pandas as pd
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Java = (CStudy["Language and IDE"] == 1).sum()
Python = (CStudy["Language and IDE"] == 2).sum()
CSharp = (CStudy["Language and IDE"] == 3).sum()
C = (CStudy["Language and IDE"] == 4).sum()
HTML = (CStudy["Language and IDE"] == 5).sum()
Minecraft = (CStudy["Language and IDE"] == 6).sum()

labels = ["Java", "Python", "C++", "C", "HTML", "Minecraft"]
sizes = [Java, Python, CSharp, C, HTML, Minecraft]
explode = (0, 0, 0, 0.1, 0.1, 0.1)
colors = ['#ff9999','#66b3ff','#99ff99','#ffcc99','#c2c2f0','#ffb3e6' ]

fig1, ax1 = plt.subplots()
piechart = ax1.pie(sizes, explode = explode, labels = labels, colors = colors, autopct='%1.1f%%')
ax1.set_title("Programming Languages") 
plt.savefig("Programming Lanaguages PieChart.png")