#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 18:59:05 2020

@author: ericbotelho
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Yes = (CStudy["Reasons you wouldnt comment?"] == 1).sum()
No = (CStudy["Reasons you wouldnt comment?"] == 2).sum()


objects = ('Yes', 'No')
y_pos = np.arange(len(objects))
Data = [Yes, No]

plt.bar(y_pos, Data, align = 'center' , alpha = 0.5)
plt.xticks(y_pos, objects)
plt.ylabel("Frequency")
plt.title("Any Reason for Failure to Document?")

plt.savefig('Any Reason for Failure to Document Bar Chart.png')