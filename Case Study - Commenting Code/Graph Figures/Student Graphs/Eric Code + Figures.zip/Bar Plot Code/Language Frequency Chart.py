#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 18:23:04 2020

@author: ericbotelho
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Java = (CStudy["Language and IDE"] == 1).sum()
Python = (CStudy["Language and IDE"] == 2).sum()
CSharp = (CStudy["Language and IDE"] == 3).sum()
C = (CStudy["Language and IDE"] == 4).sum()
HTML = (CStudy["Language and IDE"] == 5).sum()
Minecraft = (CStudy["Language and IDE"] == 6).sum()


objects = ('Java', 'Python', 'C++', 'C', 'HTML', 'Minecraft')
y_pos = np.arange(len(objects))
Data = [Java, Python, CSharp, C, HTML, Minecraft]

plt.bar(y_pos, Data, align = 'center' , alpha = 0.5)
plt.xticks(y_pos, objects)
plt.ylabel("Frequency")
plt.title("Programming Languages")

plt.savefig('Programming Languages Bar Chart.png')
