#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 18:38:54 2020

@author: ericbotelho
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Hobby = (CStudy["Why the project?"] == 1).sum()
Job = (CStudy["Why the project?"] == 2).sum()
School = (CStudy["Why the project?"] == 3).sum()
ETC = (CStudy["Why the project?"] == 4).sum()


objects = ('Hobby', 'Job', 'School','Other')
y_pos = np.arange(len(objects))
Data = [Hobby, Job, School, ETC]

plt.bar(y_pos, Data, align = 'center' , alpha = 0.5)
plt.xticks(y_pos, objects)
plt.ylabel("Frequency")
plt.title("What is the code for?")

plt.savefig('Why the Project Bar Chart.png')