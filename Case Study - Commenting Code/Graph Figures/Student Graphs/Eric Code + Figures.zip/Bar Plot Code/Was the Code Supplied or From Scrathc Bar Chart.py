#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 19 18:56:03 2020

@author: ericbotelho
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

excel_file = (r'/Users/ericbotelho/Downloads/Case_study_Results_coded.xlsx')
CStudy = pd.read_excel(excel_file)

Supplied = (CStudy["Supplied or from scratch?"] == 1).sum()
Scratch = (CStudy["Supplied or from scratch?"] == 2).sum()


objects = ('Supplied', 'From Scratch')
y_pos = np.arange(len(objects))
Data = [Supplied, Scratch]

plt.bar(y_pos, Data, align = 'center' , alpha = 0.5)
plt.xticks(y_pos, objects)
plt.ylabel("Frequency")
plt.title("Was the Code Supplied or From Scratch?")

plt.savefig('Was the Code Supplied or From Scratch Bar Chart.png')